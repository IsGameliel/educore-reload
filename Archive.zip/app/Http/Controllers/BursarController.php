<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BursarController extends Controller
{
    //
}
