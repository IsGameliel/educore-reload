<a href="/">
    <img src="{{ asset('asset/images/educore.png') }}" alt="">
</a>
