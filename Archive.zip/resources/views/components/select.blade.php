<select {{ $attributes->merge(['class' => 'mt-1 block w-full']) }}>
    {{ $slot }}
</select>
