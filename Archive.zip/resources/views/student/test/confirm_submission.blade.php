<!DOCTYPE html>
<html>
<head>
    <title>Confirm Test Submission</title>
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
</head>
<body>
    <div class="container">
        <h1>Confirm Submission</h1>
        <p>You have answered all questions for the test: {{ $test->name }}.</p>
        @if (session('error'))
            <div class="alert alert-danger">
                {{ session('error') }}
            </div>
        @endif
        <form action="{{ route('student.tests.submit', $test->id) }}" method="POST">
            @csrf
            <input type="hidden" name="submit" value="1">
            <button type="submit" class="btn btn-primary">Submit Test</button>
        </form>
        <a href="{{ route('student.tests.index') }}" class="btn btn-secondary mt-3">Cancel</a>
    </div>
</body>
</html>
